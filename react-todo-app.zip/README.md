
# React To-Do List App

This is a simple and user-friendly To-Do List application built using **React** and **Vite**.

## ✅ Features
- Add, Edit, Delete tasks
- Mark tasks as complete
- Functional Components, State & Props, Dynamic Lists
- Tailwind CSS Styling

## 🚀 Project Setup
1. Clone repository and install dependencies:
```bash
npm install
```

2. Start development server:
```bash
npm run dev
```

## 🎨 Tailwind CSS Setup
```bash
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
```
Update `tailwind.config.js` and `index.css` as shown in the app.

---

## 📂 Folder Structure
```
src/
├── components/
│   ├── Header.jsx
│   ├── ToDoItem.jsx
│   └── ToDoList.jsx
│
├── App.jsx
├── main.jsx
├── index.css
```

---

## 📝 License
For educational purposes only.
