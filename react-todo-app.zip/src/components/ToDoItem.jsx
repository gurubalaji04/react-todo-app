
import { useState } from 'react';

function ToDoItem({ task, onDelete, onToggleComplete, onEdit }) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedText, setEditedText] = useState(task.text);

  const saveEdit = () => {
    onEdit(task.id, editedText);
    setIsEditing(false);
  };

  return (
    <div className="flex items-center gap-2 bg-white p-3 rounded shadow">
      <input
        type="checkbox"
        checked={task.completed}
        onChange={() => onToggleComplete(task.id)}
      />
      {isEditing ? (
        <input
          className="border p-1 rounded flex-1"
          value={editedText}
          onChange={(e) => setEditedText(e.target.value)}
        />
      ) : (
        <span className={`flex-1 ${task.completed ? 'line-through text-gray-400' : ''}`}>
          {task.text}
        </span>
      )}
      {isEditing ? (
        <button onClick={saveEdit} className="bg-green-500 text-white px-2 py-1 rounded">
          Save
        </button>
      ) : (
        <button onClick={() => setIsEditing(true)} className="bg-yellow-400 text-white px-2 py-1 rounded">
          Edit
        </button>
      )}
      <button
        onClick={() => onDelete(task.id)}
        className="bg-red-500 text-white px-2 py-1 rounded"
      >
        Delete
      </button>
    </div>
  );
}

export default ToDoItem;
