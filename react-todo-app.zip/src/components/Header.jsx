
function Header() {
  return (
    <header className="mb-6">
      <h1 className="text-3xl font-bold text-center text-gray-700">
        To-Do List App
      </h1>
    </header>
  );
}

export default Header;
